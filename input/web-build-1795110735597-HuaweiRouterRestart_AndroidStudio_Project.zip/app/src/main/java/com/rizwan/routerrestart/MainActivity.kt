package com.rizwan.routerrestart

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private val routerUrl = "http://192.168.100.1/index.asp"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 10)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "Huawei Router Restart"
            textSize = 22f
            setTextColor(Color.rgb(25, 35, 50))
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 12)
        })
        status = TextView(this).apply {
            text = "Connect to your router Wi-Fi, then log in below."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(8, 8, 8, 12)
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "RESTART ROUTER"
            setOnClickListener { attemptRestart() }
        })
        root.addView(Button(this).apply {
            text = "Open router login / reboot page"
            setOnClickListener { web.loadUrl(routerUrl) }
        })

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                status.text = "Page loaded. Log in, then open System Tools > Reboot."
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                result.confirm()
                return true
            }
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                status.text = message ?: "Router message"
                result.confirm()
                return true
            }
        }
        root.addView(web, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        web.loadUrl(routerUrl)
    }

    private fun attemptRestart() {
        status.text = "Looking for the router Restart button..."
        val js = """
            (function() {
              function findAndClick(doc) {
                if (!doc) return false;
                var els = Array.from(doc.querySelectorAll('input,button,a'));
                var target = els.find(function(e) {
                  var s = ((e.value || '') + ' ' + (e.innerText || '') + ' ' + (e.textContent || '')).trim();
                  return /^(restart|reboot)$/i.test(s);
                });
                if (target) { target.click(); return true; }
                var frames = Array.from(doc.querySelectorAll('iframe,frame'));
                for (var i=0; i<frames.length; i++) {
                  try { if (findAndClick(frames[i].contentDocument)) return true; } catch(e) {}
                }
                return false;
              }
              return findAndClick(document);
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { result ->
            if (result == "true") {
                status.text = "Restart command sent. Waiting for router to reboot..."
            } else {
                status.text = "Restart button not found. Log in and open System Tools > Reboot."
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
