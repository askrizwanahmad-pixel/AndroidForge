# Huawei Router Restart, Android Studio starter

Target device: Huawei HG8247H, firmware V3R017C10S135, local address http://192.168.100.1.

## Use
1. Connect the Android phone to the router Wi-Fi.
2. Open the app and log in manually in the embedded browser.
3. Navigate to System Tools > Reboot.
4. Tap RESTART ROUTER in the app.
5. The app searches for a visible button/input labelled exactly Restart or Reboot and clicks it. A JavaScript confirmation dialog is accepted automatically.

## Important limitation
This is a starter project, not a verified final APK. Firmware pages differ. It may not work if this firmware uses a different button label, a form submission that does not respond to click(), or a non-JavaScript confirmation. Confirm that the router actually disconnects and returns before treating the restart as successful. A screenshot of the confirmation popup or the HTML/Network request is needed to make the automation exact.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s). The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

## Security
No router credentials are stored in the project. Login occurs locally in the WebView. HTTP is enabled because the router admin interface uses HTTP. Use only on your own trusted Wi-Fi and never expose the admin page to the public internet.
